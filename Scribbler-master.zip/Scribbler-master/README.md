# Scribbler
Creating the front-end of a blogging website using HTML, CSS and JavaScript. This blogging website enables one to register a new user, create his/her posts, edit an already existing post, add comments on a post, like a post, etc. 
